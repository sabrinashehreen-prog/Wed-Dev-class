/* ============================================
   SWEET HOPE - COMPLETE JAVASCRIPT FILE
   
   Functions included:
   1.  hamburger()           – mobile menu toggle (REQUIRED)
   2.  toggleContent()       – hide/show any element (REQUIRED)
   3.  toggleFAQ()           – FAQ accordion (uses toggleContent)
   4.  filterGallery()       – filter gallery by category
   5.  openLightbox()        – open image lightbox
   6.  closeLightbox()       – close image lightbox
   7.  validateForm()        – involvement form validation
   8.  submitContactForm()   – contact form submit handler
   9.  animateCounters()     – stats counter animation
   10. toggleDarkMode()      – dark mode toggle (bonus)

   ✏️ CHANGE: Author name below
   Author: Your Name
   ============================================ */


/* ============================================
   1. HAMBURGER MENU (REQUIRED)
   Called by: onclick="hamburger()" in HTML
   ============================================ */

function hamburger() {
    const nav       = document.getElementById('main-nav');
    const btn       = document.getElementById('hamburger-btn');
    const overlay   = document.getElementById('menu-overlay');

    // Toggle active class on all three elements
    nav.classList.toggle('active');
    btn.classList.toggle('active');
    overlay.classList.toggle('active');

    // Update aria-expanded for accessibility
    const isOpen = nav.classList.contains('active');
    btn.setAttribute('aria-expanded', isOpen);

    // Prevent background scrolling when menu is open
    document.body.style.overflow = isOpen ? 'hidden' : '';
}

// Close mobile menu when a nav link is clicked
document.addEventListener('DOMContentLoaded', function () {

    const mobileLinks = document.querySelectorAll('.main-nav a');
    mobileLinks.forEach(function (link) {
        link.addEventListener('click', function () {
            const nav     = document.getElementById('main-nav');
            const btn     = document.getElementById('hamburger-btn');
            const overlay = document.getElementById('menu-overlay');

            nav.classList.remove('active');
            btn.classList.remove('active');
            overlay.classList.remove('active');
            btn.setAttribute('aria-expanded', 'false');
            document.body.style.overflow = '';
        });
    });

    // Close menu on ESC key
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            const nav     = document.getElementById('main-nav');
            const btn     = document.getElementById('hamburger-btn');
            const overlay = document.getElementById('menu-overlay');

            if (nav && nav.classList.contains('active')) {
                nav.classList.remove('active');
                btn.classList.remove('active');
                overlay.classList.remove('active');
                btn.setAttribute('aria-expanded', 'false');
                document.body.style.overflow = '';
            }

            // Also close lightbox on ESC
            closeLightbox();
        }
    });
});


/* ============================================
   2. HIDE / SHOW CONTENT (REQUIRED)
   Called by: onclick="toggleContent('element-id', this)"
   
   Toggles display of any element by its ID.
   Updates the button text between "Learn More" and "Show Less".
   ============================================ */

function toggleContent(elementId, button) {
    var element = document.getElementById(elementId);

    if (!element) {
        console.warn('toggleContent: element #' + elementId + ' not found.');
        return;
    }

    if (element.style.display === 'none' || element.style.display === '') {
        // SHOW
        element.style.display = 'block';
        if (button) {
            // ✏️ CHANGE: Update button text labels if you prefer different wording
            button.textContent = 'Show Less';
        }
        // Smooth scroll to the revealed content
        element.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

    } else {
        // HIDE
        element.style.display = 'none';
        if (button) {
            button.textContent = 'Learn More';
        }
    }
}


/* ============================================
   3. FAQ ACCORDION
   Called by: onclick="toggleFAQ('faq-id', this)"
   Uses the same show/hide logic as toggleContent.
   ============================================ */

function toggleFAQ(faqId, questionButton) {
    var answer = document.getElementById(faqId);

    if (!answer) return;

    var isHidden = (answer.style.display === 'none' || answer.style.display === '');

    if (isHidden) {
        answer.style.display = 'block';
        if (questionButton) {
            questionButton.classList.add('active');
        }
    } else {
        answer.style.display = 'none';
        if (questionButton) {
            questionButton.classList.remove('active');
        }
    }
}


/* ============================================
   4. GALLERY FILTER
   Called by: onclick="filterGallery('category', this)"
   Shows items matching the category, hides the rest.
   ============================================ */

function filterGallery(category, clickedButton) {
    var items = document.querySelectorAll('.gallery-item');

    items.forEach(function (item) {
        var itemCategory = item.getAttribute('data-category');

        if (category === 'all' || itemCategory === category) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });

    // Update which filter button looks active
    var allButtons = document.querySelectorAll('.filter-btn');
    allButtons.forEach(function (btn) {
        btn.classList.remove('active');
    });
    if (clickedButton) {
        clickedButton.classList.add('active');
    }
}


/* ============================================
   5 & 6. LIGHTBOX
   Called by: onclick="openLightbox('image-src')"
              onclick="closeLightbox()"
   ============================================ */

function openLightbox(imageSrc) {
    var lightbox    = document.getElementById('lightbox');
    var lightboxImg = document.getElementById('lightbox-img');

    if (!lightbox || !lightboxImg) return;

    lightboxImg.src = imageSrc;
    lightbox.classList.add('active');
    document.body.style.overflow = 'hidden'; // prevent background scroll
}

function closeLightbox() {
    var lightbox = document.getElementById('lightbox');
    if (lightbox) {
        lightbox.classList.remove('active');
        document.body.style.overflow = '';
    }
}

// Close lightbox by clicking the dark background area
document.addEventListener('DOMContentLoaded', function () {
    var lightbox = document.getElementById('lightbox');
    if (lightbox) {
        lightbox.addEventListener('click', function (e) {
            // Only close if the click was directly on the overlay, not the image
            if (e.target === lightbox) {
                closeLightbox();
            }
        });
    }
});


/* ============================================
   7. FORM VALIDATION — INVOLVEMENT FORM
   Called by: the form's onsubmit event (set in HTML)
   
   ✏️ CHANGE: Add or remove validation rules to match
   your form's required fields.
   ============================================ */

document.addEventListener('DOMContentLoaded', function () {

    var form = document.getElementById('involvement-form');
    if (!form) return;

    form.addEventListener('submit', function (e) {
        e.preventDefault(); // prevent page reload

        var isValid   = true;
        var errorList = [];

        // --- Validate First Name ---
        var firstName = document.getElementById('firstName');
        if (!firstName || !firstName.value.trim()) {
            isValid = false;
            errorList.push('First name is required.');
            if (firstName) firstName.classList.add('error');
        } else {
            firstName.classList.remove('error');
        }

        // --- Validate Last Name ---
        var lastName = document.getElementById('lastName');
        if (!lastName || !lastName.value.trim()) {
            isValid = false;
            errorList.push('Last name is required.');
            if (lastName) lastName.classList.add('error');
        } else {
            lastName.classList.remove('error');
        }

        // --- Validate Email ---
        var email = document.getElementById('email');
        if (!email || !email.value.trim() || !email.value.includes('@')) {
            isValid = false;
            errorList.push('A valid email address is required.');
            if (email) email.classList.add('error');
        } else {
            email.classList.remove('error');
        }

        // --- Validate Terms Checkbox ---
        var terms = document.getElementById('terms');
        if (!terms || !terms.checked) {
            isValid = false;
            errorList.push('You must agree to the terms and conditions.');
        }

        // --- Result ---
        if (isValid) {
            // Show success message and hide form
            var successMsg = document.getElementById('form-success');
            if (successMsg) {
                successMsg.style.display = 'block';
                form.style.display = 'none';
                successMsg.scrollIntoView({ behavior: 'smooth' });
            }
        } else {
            // Show error summary
            alert('Please fix the following errors:\n\n• ' + errorList.join('\n• '));
        }
    });

    // Handle "Other" donation amount visibility
    var otherRadio  = document.getElementById('otherRadio');
    var otherAmount = document.getElementById('otherAmount');

    if (otherRadio && otherAmount) {
        document.querySelectorAll('input[name="donationAmount"]').forEach(function (radio) {
            radio.addEventListener('change', function () {
                otherAmount.style.display = (this.value === 'other') ? 'block' : 'none';
            });
        });
    }
});


/* ============================================
   8. CONTACT FORM SUBMIT HANDLER
   Called by: onclick="submitContactForm(event)"
   ============================================ */

function submitContactForm(e) {
    e.preventDefault();

    var name    = document.getElementById('contact-name');
    var email   = document.getElementById('contact-email');
    var message = document.getElementById('contact-message');

    var isValid  = true;
    var errors   = [];

    if (!name || !name.value.trim()) {
        isValid = false;
        errors.push('Your name is required.');
        if (name) name.classList.add('error');
    } else {
        name.classList.remove('error');
    }

    if (!email || !email.value.trim() || !email.value.includes('@')) {
        isValid = false;
        errors.push('A valid email is required.');
        if (email) email.classList.add('error');
    } else {
        email.classList.remove('error');
    }

    if (!message || !message.value.trim()) {
        isValid = false;
        errors.push('Please enter a message.');
        if (message) message.classList.add('error');
    } else {
        message.classList.remove('error');
    }

    if (isValid) {
        var successMsg = document.getElementById('contact-success');
        var form       = document.getElementById('contact-form');
        if (successMsg && form) {
            successMsg.style.display = 'block';
            form.style.display       = 'none';
            successMsg.scrollIntoView({ behavior: 'smooth' });
        }
    } else {
        alert('Please fix the following:\n\n• ' + errors.join('\n• '));
    }
}


/* ============================================
   9. ANIMATED STATS COUNTER
   Runs on page load for index.html.
   Looks for elements with class "stat-number"
   and a data-target attribute.
   
   ✏️ CHANGE: Update data-target values in index.html
   to match your NPO's stats.
   ============================================ */

function animateCounters() {
    var counters = document.querySelectorAll('.stat-number');
    if (counters.length === 0) return;

    counters.forEach(function (counter) {
        var target   = parseInt(counter.getAttribute('data-target'), 10);
        var duration = 1800; // milliseconds
        var start    = 0;
        var step     = target / (duration / 16); // ~60fps

        var timer = setInterval(function () {
            start += step;
            if (start >= target) {
                start = target;
                clearInterval(timer);
            }
            // Use toLocaleString so numbers like 86440 display as 86,440
            counter.textContent = Math.round(start).toLocaleString();
        }, 16);
    });
}

// Only run counters when the stat elements are in the viewport
document.addEventListener('DOMContentLoaded', function () {
    var statBar = document.querySelector('.stats-bar');
    if (!statBar) return;

    // Use IntersectionObserver for a smooth trigger
    if ('IntersectionObserver' in window) {
        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    animateCounters();
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.3 });

        observer.observe(statBar);
    } else {
        // Fallback for older browsers
        animateCounters();
    }
});


/* ============================================
   10. DARK MODE TOGGLE (BONUS)
   Called by: onclick="toggleDarkMode()"
   ============================================ */

function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    localStorage.setItem('sweethope-darkmode', document.body.classList.contains('dark-mode'));
    
    const toggleBtn = document.querySelector('.dark-mode-toggle');
    if (toggleBtn) {
        toggleBtn.textContent = document.body.classList.contains('dark-mode') ? '☀️' : '🌙';
    }
}

// Load saved preference
if (localStorage.getItem('sweethope-darkmode') === 'true') {
    document.body.classList.add('dark-mode');
}

// Apply saved dark mode preference on page load
document.addEventListener('DOMContentLoaded', function () {
    if (localStorage.getItem('sweethope-darkmode') === 'true') {
        document.body.classList.add('dark-mode');
        var toggleBtn = document.querySelector('.dark-mode-toggle');
        if (toggleBtn) {
            toggleBtn.textContent = '☀️';
        }
    }
});


/* ============================================
   SMOOTH SCROLLING for anchor links
   ============================================ */

document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
        anchor.addEventListener('click', function (e) {
            var href = this.getAttribute('href');
            if (href === '#' || href === '') return;
            var target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
});
